export { assets, base } from '../paths.js';
