<script>
	import Logo from '../assets/img/Logo.png';
</script>

<img class="z-20" style="width: 85px; height: 85px;" src={Logo} alt="logo" />
