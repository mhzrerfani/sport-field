<script>
	import Logo from '../assets/img/Logo.png';
</script>

<img class="z-20" style="width: 55px; height: 55px;" src={Logo} alt="logo" />
